﻿using System.Collections.Generic;

namespace demo1
{
    public class Photo
    {
        public Photo(string path)
        {
            Source = path;
        }

        public string Source { get; }

        public override string ToString() => Source;

        public static List<Photo> GetPhotos()
        {
            // Agrega las rutas de tus fotos aquí
            var photoPaths = new List<string>
            {
                "/resources/fondo.jpg",
                "/resources/gato.jpg",
                "/resources/minions.jpg",
                // Agrega más rutas de fotos según tus necesidades
            };

            var photos = new List<Photo>();

            foreach (var path in photoPaths)
            {
                photos.Add(new Photo(path));
            }

            return photos;
        }
    }
}
